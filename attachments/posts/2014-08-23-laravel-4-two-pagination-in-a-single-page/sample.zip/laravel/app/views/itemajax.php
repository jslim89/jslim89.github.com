<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Multi pagination - Laravel 4</title>

    <!-- Bootstrap core CSS -->
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
<style>
.main-wrapper {
    padding-top: 80px;
}
</style>
  </head>

  <body>

    <div class="navbar navbar-inverse navbar-fixed-top" role="navigation">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="#">Multi Pagin Demo</a>
        </div>
        <div class="collapse navbar-collapse">
        </div><!--/.nav-collapse -->
      </div>
    </div>

    <div class="main-wrapper">

      <div class="container">
        <!-- Nav tabs -->
        <ul class="nav nav-tabs" role="tablist">
          <li class="active"><a href="#impression" role="tab" data-toggle="tab">Impression</a></li>
          <li><a href="#conversion" role="tab" data-toggle="tab">Conversion</a></li>
        </ul>

        <!-- Tab panes -->
        <div class="tab-content">

          <div class="tab-pane active" id="impression">
          </div><!-- /#impression -->

          <div class="tab-pane" id="conversion">
          </div><!-- /#conversion -->

        </div>
      </div><!-- /.container -->

    </div><!-- /.main-wrapper -->


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
    <script>
    $(function() {
        function getPaginationSelectedPage(url) {
            var chunks = url.split('?');
            var baseUrl = chunks[0];
            var querystr = chunks[1].split('&');
            var pg = 1;
            for (i in querystr) {
                var qs = querystr[i].split('=');
                if (qs[0] == 'page') {
                    pg = qs[1];
                    break;
                }
            }
            return pg;
        }

        $('#impression').on('click', '.pagination a', function(e) {
            e.preventDefault();
            var pg = getPaginationSelectedPage($(this).attr('href'));

            $.ajax({
                url: '/items/ajax/impression',
                data: { page: pg },
                success: function(data) {
                    $('#impression').html(data);
                }
            });
        });

        $('#conversion').on('click', '.pagination a', function(e) {
            e.preventDefault();
            var pg = getPaginationSelectedPage($(this).attr('href'));

            $.ajax({
                url: '/items/ajax/conversion',
                data: { page: pg },
                success: function(data) {
                    $('#conversion').html(data);
                }
            });
        });

        // first load
        $('#impression').load('/items/ajax/impression?page=1');
        $('#conversion').load('/items/ajax/conversion?page=1');
    });
    </script>
  </body>
</html>
