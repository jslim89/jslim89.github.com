<table class="table">
  <thead>
    <tr>
      <th>ID</th>
      <th>Key</th>
    </tr>
  </thead>
  <tbody>
    <?php foreach ($items as $item): ?>
    <tr>
      <td><?php echo $item->id; ?></td>
      <td><?php echo $item->key; ?></td>
    </tr>
    <?php endforeach; ?>
  </tbody>
</table>
<?php echo $items->appends(Input::except('page'))->links(); ?>
