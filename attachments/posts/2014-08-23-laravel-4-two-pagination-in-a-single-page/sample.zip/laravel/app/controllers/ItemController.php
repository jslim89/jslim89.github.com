<?php
define('ITEMS_PER_PAGE', 10);

class ItemController extends BaseController
{
	public function getIndex()
	{
		return View::make('itemajax');
	}

	public function getIndexNoAjax()
	{
        $impressions = Impression::paginate(ITEMS_PER_PAGE);
        $conversions = Conversion::paginate(ITEMS_PER_PAGE);
        return View::make('itemnoajax')
            ->with('impressions', $impressions)
            ->with('conversions', $conversions);
	}

	public function getItemType($type)
	{
        if ($type == 'impression') {
            $items = Impression::paginate(ITEMS_PER_PAGE);
        } else {
            $items = Conversion::paginate(ITEMS_PER_PAGE);
        }

        $view = View::make('item_type')->with('items', $items);
        echo $view;
        exit;
	}
}
